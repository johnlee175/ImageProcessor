function open_code (text) 
{
var url="../../help/codes.html#" +text;
remote = window.open(url,"Codes",'toolbar=no,directories=no,menubar=no,status=no,scrollbars=yes,resizable=yes,width=350,height=480,alwaysRaised=yes');
}
